
<!---
Version: 1.0 
-->
# Exercise 1: Configure Storage Spaces Direct
## INTRODUCTION MESSAGE
In this exercise, you will confiure Storage Spaces Direct by first creating a Scale-Out File Server in which you specify that the storage is attached directly to each cluster node. You will also configure a storae pool and a file share in which you specify teh size, the file system, and the resiliency type.
## COMPLETION MESSAGE
Congratulation!  
  
You have successfully configured a CSV and Storage Spaces Direct.  
  
Click *Continue* to proceed to the next exercise.
### Task with breaks
This is a task that has   
breaks between the lines  
that show as bracket, br, slash bracket  
single spaced






